﻿using Microsoft.AspNetCore.Mvc;

namespace HFilesAPI.Models
{
    public class ProfileUploadModel
    {
        [FromForm(Name = "file")]
        public IFormFile File { get; set; }
    }
}
