'use client';

import React, { useState, useRef } from 'react';
import { api } from '../../services/api';

interface FileUploadFormProps {
  onFileUpload: () => void;
  currentFilesCount: number;
  onFileSelect: (files: File[]) => void;
  previewFiles: File[];
  setPreviewFiles: React.Dispatch<React.SetStateAction<File[]>>;
}

const FileUploadForm: React.FC<FileUploadFormProps> = ({
  onFileUpload,
  currentFilesCount,
  onFileSelect,
  previewFiles,
  setPreviewFiles,
}) => {
  const [formData, setFormData] = useState({ fileType: '', fileName: '' });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileTypes = [
    'Lab Report', 'Prescription', 'X-Ray', 'Blood Report',
    'MRI Scan', 'CT Scan', 'Medical Certificate', 'Discharge Summary'
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);

      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];

      const validFiles = newFiles.filter((file) => {
        if (!allowedTypes.includes(file.type)) {
          setMessage('Supported formats: PDF, JPG, JPEG, PNG');
          return false;
        }
        if (file.size > 10 * 1024 * 1024) {
          setMessage('File must be less than 10MB');
          return false;
        }
        return true;
      });

      if (validFiles.length > 0) {
        setMessage('');
        onFileSelect(validFiles); // ✅ push files to parent preview
        if (!formData.fileName) {
          const fileNameWithoutExt = validFiles[0].name.replace(/\.[^/.]+$/, '');
          setFormData({ ...formData, fileName: fileNameWithoutExt });
        }
      }
    }
  };

  // Trigger file selection when "Upload Files" button is clicked
  const handleFileSelectButton = () => {
    fileInputRef.current?.click();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (currentFilesCount >= 5) {
      setMessage('You can only upload up to 5 files');
      return;
    }

    if (previewFiles.length === 0) {
      setMessage('Please select at least one file to upload');
      return;
    }

    setLoading(true);
    setMessage('');

    try {
      const uploadData = new FormData();

      // ✅ Must match DTO property names
      previewFiles.forEach((file) => {
        uploadData.append('files', file);
      });

      uploadData.append('fileType', formData.fileType);
      uploadData.append('fileName', formData.fileName);

      await api.uploadFile(uploadData);

      setMessage('Files uploaded successfully');
      setFormData({ fileType: '', fileName: '' });
      setPreviewFiles([]); // ✅ clear after success
      if (fileInputRef.current) fileInputRef.current.value = ''; // reset input

      onFileUpload();
    } catch (err: any) {
      setMessage(err.message || 'Failed to upload file');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {message && (
        <div
          className={`mb-4 px-4 py-3 rounded ${
            message.includes('successfully')
              ? 'bg-green-100 border border-green-400 text-green-700'
              : 'bg-red-100 border border-red-400 text-red-700'
          }`}
        >
          {message}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* File Type */}
        <select
          name="fileType"
          value={formData.fileType}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
          required
        >
          <option value="">Select file type</option>
          {fileTypes.map((type) => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>

        {/* File Name */}
        <input
          type="text"
          name="fileName"
          value={formData.fileName}
          onChange={handleChange}
          placeholder="Enter Name of File..."
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
          required
        />

        {/* Hidden File Input */}
        <input
          type="file"
          ref={fileInputRef}
          style={{ display: 'none' }}
          onChange={handleFileChange}
          accept=".pdf,image/jpeg,image/png,image/jpg"
          multiple   // ✅ allow multiple files
        />

        {/* Buttons: Upload Files + Submit */}
        <div className="flex justify-between mt-4">
          <button
            type="button"
            onClick={handleFileSelectButton}
            className="bg-blue-600 text-white px-4 py-2 rounded-full font-semibold hover:bg-blue-700"
          >
            Upload Files
          </button>

          <button
            type="submit"
            className="bg-yellow-400 text-white px-4 py-2 rounded-full font-bold shadow hover:bg-yellow-500"
            disabled={loading}
          >
            {loading ? 'Uploading...' : 'Submit'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default FileUploadForm;
