﻿using HFilesAPI.Models;
using HFilesAPI.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HFilesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<UsersController> _logger;
        private readonly IWebHostEnvironment _env;

        public UsersController(IUserRepository userRepo, ILogger<UsersController> logger, IWebHostEnvironment env)
        {
            _userRepo = userRepo;
            _logger = logger;
            _env = env;
        }

        [HttpGet("me")]
        public async Task<IActionResult> Me()
        {
            try
            {
                if (!User.Identity?.IsAuthenticated ?? true)
                    return Unauthorized(new { message = "User is not authenticated" });

                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
                var user = await _userRepo.GetByIdAsync(userId);

                if (user == null)
                    return NotFound(new { message = "User not found" });

                return Ok(new { user.Id, user.FullName, user.Email, user.Gender, user.Phone });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching profile for UserId={UserId}",
                                 User.FindFirstValue(ClaimTypes.NameIdentifier));
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while fetching the profile." });
            }
        }

        [HttpPut("me")]
        public async Task<IActionResult> Update([FromBody] UpdateProfileModel dto)
        {
            try
            {
                if (!User.Identity?.IsAuthenticated ?? true)
                    return Unauthorized(new { message = "User is not authenticated" });

                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
                var user = await _userRepo.GetByIdAsync(userId);

                if (user == null)
                    return NotFound(new { message = "User not found" });

                // Update fields
                user.FullName = dto.FullName;
                user.Email = dto.Email;
                user.Gender = dto.Gender;
                user.Phone = dto.Phone;

                await _userRepo.UpdateProfileAsync(user);

                return Ok(new { message = "Profile updated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating profile for UserId={UserId}",
                                 User.FindFirstValue(ClaimTypes.NameIdentifier));
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while updating the profile." });
            }
        }

        [Authorize]
        [HttpPost("profile-image")]
        public async Task<IActionResult> UploadProfileImage([FromForm] ProfileUploadModel dto)
        {
            try
            {
                // Debug: Log the incoming request
                _logger.LogInformation("UploadProfileImage called");

                if (dto.File == null || dto.File.Length == 0)
                {
                    _logger.LogWarning("No file provided");
                    return BadRequest(new { message = "File is required" });
                }

                _logger.LogInformation($"File received: {dto.File.FileName}, ContentType: {dto.File.ContentType}, Size: {dto.File.Length}");

                var allowed = new[] { "image/jpeg", "image/png", "image/jpg" };
                if (!allowed.Contains(dto.File.ContentType))
                {
                    _logger.LogWarning($"Invalid file type: {dto.File.ContentType}");
                    return BadRequest(new { message = "Only JPG and PNG images are allowed" });
                }

                // Get user ID from claims
                var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userIdClaim))
                {
                    _logger.LogWarning("User ID claim not found");
                    return Unauthorized(new { message = "User not authenticated" });
                }

                if (!int.TryParse(userIdClaim, out var userId))
                {
                    _logger.LogWarning($"Invalid user ID format: {userIdClaim}");
                    return BadRequest(new { message = "Invalid user ID" });
                }

                _logger.LogInformation($"Processing profile image for user ID: {userId}");

                var ext = Path.GetExtension(dto.File.FileName);
                var storedFileName = $"profile-{userId}{ext}";

                var uploadsPath = Path.Combine(_env.WebRootPath ?? _env.ContentRootPath, "Uploads", "Profiles");
                Directory.CreateDirectory(uploadsPath);

                var path = Path.Combine(uploadsPath, storedFileName);
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await dto.File.CopyToAsync(stream);
                }

                var user = await _userRepo.GetByIdAsync(userId);
                if (user == null) return NotFound();

                user.ProfileImage = $"/Uploads/Profiles/{storedFileName}";
                await _userRepo.UpdateProfileImageAsync(user.Id, user.ProfileImage);

                return Ok(new { filePath = user.ProfileImage });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading profile image");
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while uploading profile image." });
            }
        }

        [HttpGet("profile-image/{userId}")]
        [AllowAnonymous] // Allow access without authentication if needed
        public async Task<IActionResult> GetProfileImage(int userId)
        {
            try
            {
                var user = await _userRepo.GetByIdAsync(userId);
                if (user == null || string.IsNullOrEmpty(user.ProfileImage))
                {
                    return NotFound(new { message = "Profile image not found" });
                }

                // Get the physical file path
                var filePath = Path.Combine(_env.WebRootPath ?? _env.ContentRootPath, user.ProfileImage.TrimStart('/'));

                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound(new { message = "Profile image file not found" });
                }

                // Determine content type based on file extension
                var contentType = "image/jpeg"; // default
                var extension = Path.GetExtension(filePath).ToLower();
                switch (extension)
                {
                    case ".png":
                        contentType = "image/png";
                        break;
                    case ".gif":
                        contentType = "image/gif";
                        break;
                    case ".bmp":
                        contentType = "image/bmp";
                        break;
                }

                // Return the physical file
                return PhysicalFile(filePath, contentType);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving profile image for user ID {UserId}", userId);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while retrieving profile image." });
            }
        }
    }
}
