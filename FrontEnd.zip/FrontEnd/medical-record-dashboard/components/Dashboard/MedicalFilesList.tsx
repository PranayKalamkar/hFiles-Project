'use client';

import React from 'react';
import { MedicalFile } from '../../types';
import { api } from '../../services/api';

interface MedicalFilesListProps {
  files: MedicalFile[];
  setFiles: React.Dispatch<React.SetStateAction<MedicalFile[]>>;
  selectedFile: MedicalFile | null;
  setSelectedFile: React.Dispatch<React.SetStateAction<MedicalFile | null>>;
  previewFiles: File[];
  setPreviewFiles: React.Dispatch<React.SetStateAction<File[]>>;
}

const MedicalFilesList: React.FC<MedicalFilesListProps> = ({
  files,
  setFiles,
  selectedFile,
  setSelectedFile,
  previewFiles,
  setPreviewFiles,
}) => {
  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this file?')) return;
    try {
      await api.deleteFile(id);
      setFiles(files.filter((file) => file.id !== id));
      if (selectedFile?.id === id) setSelectedFile(null);
    } catch (err: any) {
      alert(err.message || 'Failed to delete file');
    }
  };

  const removePreview = (index: number) => {
    const updated = [...previewFiles];
    updated.splice(index, 1);
    setPreviewFiles(updated);
  };

  return (
    <div className="mt-6 space-y-8">
      {/* Uploaded Files */}
      {files.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Uploaded Files</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.map((file) => (
              <div key={file.id} className="bg-white shadow rounded-lg p-3">
                {file.filePath.toLowerCase().endsWith('.pdf') ? (
                  <div className="text-center text-sm">📄 {file.fileName}</div>
                ) : (
                  <img
                    src={file.filePath}
                    alt={file.fileName}
                    className="w-full h-32 object-contain rounded"
                  />
                )}
                <div className="flex justify-between mt-2">
                  <button
                    onClick={() => setSelectedFile(file)}
                    className="text-xs text-blue-600 hover:underline"
                  >
                    Preview
                  </button>
                  <button
                    onClick={() => handleDelete(file.id)}
                    className="text-xs text-red-600 hover:underline"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Preview Files */}
      {previewFiles.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Preview of selected files
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {previewFiles.map((file, index) => {
              const previewUrl = URL.createObjectURL(file);
              return (
                <div
                  key={index}
                  className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-md p-2 flex flex-col items-center shadow-sm"
                >
                  {file.type === 'application/pdf' ? (
                    <div className="text-xs text-center">📄 {file.name}</div>
                  ) : (
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="w-full h-24 object-contain rounded"
                    />
                  )}
                  <div className="flex justify-between items-center mt-1 w-full">
                    <span className="text-[11px] text-gray-500 truncate flex-1">
                      {file.name}
                    </span>
                    <button
                      onClick={() => removePreview(index)}
                      className="text-[11px] text-red-500 ml-2 hover:underline"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicalFilesList;
