﻿using HFilesAPI.Models;

namespace HFilesAPI.Repositories
{
    public interface IFileRepository
    {
        Task<int> AddAsync(MedicalFileModel file);
        Task<IEnumerable<MedicalFileModel>> GetByUserAsync(int userId);
        Task<MedicalFileModel?> GetByIdAsync(int id);
        Task DeleteAsync(int id);
    }
}
