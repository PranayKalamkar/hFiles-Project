// types/index.ts
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data: T;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface RegisterData {
  fullName: string;
  email: string;
  gender: string;
  phone: string;
  password: string;
}

export interface User {
  id: number;
  fullName: string;
  email: string;
  gender: string;
  phone: string;
  profileImage?: string;
}

export interface MedicalFile {
  id: number;
  userId: number;
  fileType: string;
  fileName: string;
  filePath: string;
  originalFileName: string;
  uploadedAt: string;
}

export interface FileUploadResponse {
  filePath: string;
}