'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import FileUploadForm from '../../components/Dashboard/FileUploadForm';
import MedicalFilesList from '../../components/Dashboard/MedicalFilesList';
import { MedicalFile } from '../../types';
import { api } from '../../services/api';
import { auth } from '../../services/auth';

const DashboardPage = () => {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [files, setFiles] = useState<MedicalFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<MedicalFile | null>(null);
  const [loading, setLoading] = useState(true);

  // Profile state
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [profileData, setProfileData] = useState<any>(null);
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileMessage, setProfileMessage] = useState('');

  // File preview state (multiple uploads)
  const [previewFiles, setPreviewFiles] = useState<File[]>([]);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 🔐 Authentication + Load files
  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push('/auth/login');
      return;
    }
    const currentUser = auth.getUser();
    if (currentUser) {
      setUser(currentUser);
      setProfileData(currentUser);
    }
    loadFiles();
  }, [router]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setUserDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadFiles = async () => {
    try {
      const filesData = await api.getFiles();
      setFiles(filesData);
      if (filesData.length > 0) {
        setSelectedFile(filesData[filesData.length - 1]);
      }
    } catch (err) {
      console.error('Failed to load files:', err);
    } finally {
      setLoading(false);
    }
  };

  // Profile helpers
  const handleLogout = () => auth.logout();
  const getProfileImageUrl = () => api.getImageUrl(user?.profileImage);
  const getInitials = (name: string) =>
    name.split(' ').map((part) => part[0]).join('').toUpperCase().slice(0, 2);
  const toggleUserDropdown = () => setUserDropdownOpen(!userDropdownOpen);

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (profileData) {
      setProfileData({ ...profileData, [e.target.name]: e.target.value });
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedTypes.includes(file.type)) {
        setProfileMessage('Only JPG and PNG images are allowed');
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setProfileMessage('Image must be less than 5MB');
        return;
      }
      setProfileImage(file);
      setProfileMessage('');
      const reader = new FileReader();
      reader.onload = () => setPreviewUrl(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const uploadProfileImage = async () => {
    if (!profileImage) return null;
    try {
      const formData = new FormData();
      formData.append('file', profileImage);
      const response = await api.uploadProfileImage(formData);
      return response.filePath;
    } catch (err: any) {
      setProfileMessage(err.message || 'Failed to upload profile image');
      return null;
    }
  };

  const handleSaveProfile = async () => {
    if (!profileData) return;
    setProfileLoading(true);
    setProfileMessage('');
    try {
      let profileImagePath = profileData.profileImage;
      if (profileImage) {
        profileImagePath = await uploadProfileImage();
        if (!profileImagePath) return;
      }
      const updatedUser = {
        ...profileData,
        profileImage: profileImagePath || profileData.profileImage,
      };
      await api.updateProfile(updatedUser);
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      setProfileMessage('Profile updated successfully');
      setProfileImage(null);
      setPreviewUrl(null);
    } catch (err: any) {
      setProfileMessage(err.message || 'Failed to update profile');
    } finally {
      setProfileLoading(false);
    }
  };

  // 📂 File upload helpers
  const handleFileUpload = async () => {
    await loadFiles();
  };

  const handleFileSelect = (newFiles: File[]) => {
    setPreviewFiles((prev) => {
      const merged = [...prev, ...newFiles];
      return merged.slice(0, 5); // ✅ limit total preview to 5
    });
  };

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-blue-700 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="bg-white p-2 rounded-lg">
              <svg
                className="w-6 h-6 text-blue-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">hfiles</h1>
              <p className="text-xs text-blue-100">HEALTH FILES</p>
            </div>
          </div>
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={toggleUserDropdown}
              className="flex items-center space-x-2 focus:outline-none"
            >
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center overflow-hidden border-2 border-blue-300">
                {getProfileImageUrl() ? (
                  <img
                    src={getProfileImageUrl()}
                    alt="Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-blue-600 font-semibold text-sm">
                    {user ? getInitials(user.fullName) : 'U'}
                  </span>
                )}
              </div>
            </button>
            {userDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border">
                <div className="px-4 py-2 border-b">
                  <p className="text-sm font-medium text-gray-900">
                    {user?.fullName}
                  </p>
                  <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Profile Card */}
          <div className="bg-blue-50 rounded-lg shadow-lg p-8 flex flex-col relative">
            <div className="absolute top-6 right-6 bg-white px-4 py-2 rounded-full text-xs font-semibold shadow border">
              {user?.id || 'PH5437CV76B'}
            </div>
            {profileMessage && (
              <div
                className={`mb-4 px-4 py-3 rounded ${
                  profileMessage.includes('successfully')
                    ? 'bg-green-100 border border-green-400 text-green-700'
                    : 'bg-red-100 border border-red-400 text-red-700'
                }`}
              >
                {profileMessage}
              </div>
            )}
            <div className="flex items-center space-x-7 mb-8">
              <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-blue-400 bg-white flex items-center justify-center">
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt="Profile preview"
                    className="w-full h-full object-cover"
                  />
                ) : user?.profileImage ? (
                  <img
                    src={api.getImageUrl(user.profileImage)}
                    alt="Profile"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <span className="text-blue-600 font-bold text-3xl">
                    {user ? getInitials(user.fullName) : 'U'}
                  </span>
                )}
              </div>
              <div className="flex-1">
                <div className="text-xl font-bold text-blue-700 mb-1">
                  {profileData?.fullName}
                </div>
                <div className="mb-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageChange}
                    accept="image/jpeg,image/png,image/jpg"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-sm text-blue-700 underline"
                  >
                    Change
                  </button>
                </div>
                <div className="flex flex-col space-y-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={profileData?.email || ''}
                      onChange={handleProfileChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Phone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={profileData?.phone || ''}
                      onChange={handleProfileChange}
                      className="w-full px-3 py-2 border rounded-md border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Gender
                    </label>
                    <div className="flex space-x-5 mt-2">
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          name="gender"
                          value="Male"
                          checked={profileData?.gender === 'Male'}
                          onChange={handleProfileChange}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2">Male</span>
                      </label>
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          name="gender"
                          value="Female"
                          checked={profileData?.gender === 'Female'}
                          onChange={handleProfileChange}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2">Female</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex justify-end items-center mt-4">
              <button
                onClick={handleSaveProfile}
                disabled={profileLoading}
                className="bg-yellow-400 text-white px-4 py-2 rounded-full font-bold shadow hover:bg-yellow-500"
              >
                {profileLoading ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>

          {/* Medical Records Card */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Medical Records
            </h2>
            <FileUploadForm
              onFileUpload={handleFileUpload}
              currentFilesCount={files.length}
              onFileSelect={handleFileSelect}
              previewFiles={previewFiles}
              setPreviewFiles={setPreviewFiles}
            />
          </div>
        </div>

        {/* Preview Files + Uploaded Files */}
        <div className="mt-8">
          <MedicalFilesList
            files={files}
            setFiles={setFiles}
            selectedFile={selectedFile}
            setSelectedFile={setSelectedFile}
            previewFiles={previewFiles}
            setPreviewFiles={setPreviewFiles}
          />
        </div>
      </main>
    </div>
  );
};

export default DashboardPage;
