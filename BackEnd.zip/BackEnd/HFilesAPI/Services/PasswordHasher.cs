﻿using System.Security.Cryptography;

namespace HFilesAPI.Services
{
    public static class PasswordHasher
    {
        public static string Hash(string password)
        {
            var salt = RandomNumberGenerator.GetBytes(16);
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 100_000, HashAlgorithmName.SHA256);
            var hash = pbkdf2.GetBytes(32);
            var result = new byte[salt.Length + hash.Length];
            Buffer.BlockCopy(salt, 0, result, 0, salt.Length);
            Buffer.BlockCopy(hash, 0, result, salt.Length, hash.Length);
            return Convert.ToBase64String(result);
        }

        public static bool Verify(string password, string storedBase64)
        {
            var stored = Convert.FromBase64String(storedBase64);
            var salt = new byte[16];
            var hash = new byte[32];
            Buffer.BlockCopy(stored, 0, salt, 0, salt.Length);
            Buffer.BlockCopy(stored, salt.Length, hash, 0, hash.Length);
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 100_000, HashAlgorithmName.SHA256);
            var computed = pbkdf2.GetBytes(32);
            return CryptographicOperations.FixedTimeEquals(computed, hash);
        }
    }
}
