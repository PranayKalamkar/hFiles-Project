﻿using HFilesAPI.Data;
using HFilesAPI.Models;
using MySql.Data.MySqlClient;
using System.Data;

namespace HFilesAPI.Repositories
{
    public class FileRepository : IFileRepository
    {
        private readonly IDbConnectionFactory _factory;
        private readonly ILogger<FileRepository> _logger;

        public FileRepository(IDbConnectionFactory factory, ILogger<FileRepository> logger)
        {
            _factory = factory;
            _logger = logger;
        }

        public async Task<int> AddAsync(MedicalFileModel file)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_AddMedicalFile";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new MySqlParameter("p_user_id", file.UserId));
                cmd.Parameters.Add(new MySqlParameter("p_file_type", file.FileType));
                cmd.Parameters.Add(new MySqlParameter("p_file_name", file.FileName));
                cmd.Parameters.Add(new MySqlParameter("p_stored_file_name", file.StoredFileName));
                cmd.Parameters.Add(new MySqlParameter("p_mime_type", file.MimeType));
                cmd.Parameters.Add(new MySqlParameter("p_size_bytes", file.SizeBytes));
                cmd.Parameters.Add(new MySqlParameter("p_created_at", file.CreatedAt));

                var outId = new MySqlParameter("p_id", MySqlDbType.Int32)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outId);

                await cmd.ExecuteNonQueryAsync();
                return Convert.ToInt32(outId.Value);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while adding medical file for UserId={UserId}", file.UserId);
                throw; // rethrow so controller can handle it
            }
        }

        public async Task<IEnumerable<MedicalFileModel>> GetByUserAsync(int userId)
        {
            var list = new List<MedicalFileModel>();
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_GetFilesByUser";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new MySqlParameter("p_user_id", userId));

                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    list.Add(new MedicalFileModel
                    {
                        Id = reader.GetInt32("id"),
                        UserId = reader.GetInt32("user_id"),
                        FileType = reader.GetString("file_type"),
                        FileName = reader.GetString("file_name"),
                        StoredFileName = reader.GetString("stored_file_name"),
                        MimeType = reader["mime_type"] as string,
                        SizeBytes = reader.GetInt64("size_bytes"),
                        CreatedAt = reader.GetDateTime("created_at")
                    });
                }
                return list;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while fetching files for UserId={UserId}", userId);
                throw;
            }
        }

        public async Task<MedicalFileModel?> GetByIdAsync(int id)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_GetFileById";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new MySqlParameter("p_id", id));

                using var reader = await cmd.ExecuteReaderAsync();
                if (!await reader.ReadAsync()) return null;

                return new MedicalFileModel
                {
                    Id = reader.GetInt32("id"),
                    UserId = reader.GetInt32("user_id"),
                    FileType = reader.GetString("file_type"),
                    FileName = reader.GetString("file_name"),
                    StoredFileName = reader.GetString("stored_file_name"),
                    MimeType = reader["mime_type"] as string,
                    SizeBytes = reader.GetInt64("size_bytes"),
                    CreatedAt = reader.GetDateTime("created_at")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while fetching file by Id={FileId}", id);
                throw;
            }
        }

        public async Task DeleteAsync(int id)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_DeleteFile";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new MySqlParameter("p_id", id));

                await cmd.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while deleting file Id={FileId}", id);
                throw;
            }
        }
    }
}
