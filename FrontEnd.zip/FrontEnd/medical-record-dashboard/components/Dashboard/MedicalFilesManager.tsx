'use client';

import React, { useState, useEffect } from 'react';
import FileUploadForm from './FileUploadForm';
import MedicalFilesList from './MedicalFilesList';
import { MedicalFile } from '../../types';
import { api } from '../../services/api';

const MedicalFilesManager: React.FC = () => {
  const [files, setFiles] = useState<MedicalFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<MedicalFile | null>(null);
  const [previewFiles, setPreviewFiles] = useState<File[]>([]);

  const fetchFiles = async () => {
    const data = await api.getFiles();
    setFiles(data);
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  return (
    <div>
      <FileUploadForm
        onFileUpload={fetchFiles}
        currentFilesCount={files.length}
        onFileSelect={(newFiles) => setPreviewFiles((prev) => [...prev, ...newFiles])}
        previewFiles={previewFiles}
        setPreviewFiles={setPreviewFiles}
      />

      <MedicalFilesList
        files={files}
        setFiles={setFiles}
        selectedFile={selectedFile}
        setSelectedFile={setSelectedFile}
        previewFiles={previewFiles}
        setPreviewFiles={setPreviewFiles}
      />
    </div>
  );
};

export default MedicalFilesManager;
