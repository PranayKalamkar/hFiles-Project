﻿using HFilesAPI.Models;
using HFilesAPI.Repositories;
using HFilesAPI.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace HFilesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepo;
        private readonly ILogger<AuthController> _logger;
        private IConfiguration _config;

        public AuthController(IUserRepository userRepo, ILogger<AuthController> logger, IConfiguration config)
        {
            _userRepo = userRepo;
            _logger = logger;
            _config = config;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel dto)
        {
            try
            {
                var existing = await _userRepo.GetByEmailAsync(dto.Email);
                if (existing != null)
                    return BadRequest(new { message = "Email already in use" });

                var user = new UserModel
                {
                    FullName = dto.FullName,
                    Email = dto.Email,
                    Gender = dto.Gender,
                    Phone = dto.Phone,
                    PasswordHash = PasswordHasher.Hash(dto.Password),
                    CreatedAt = DateTime.UtcNow
                };

                var id = await _userRepo.CreateUserAsync(user);
                user.Id = id;

                return Ok(new { id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during registration for Email={Email}", dto.Email);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while registering the user." });
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel dto)
        {
            try
            {
                var user = await _userRepo.GetByEmailAsync(dto.Email);
                if (user == null)
                    return Unauthorized(new { message = "Invalid credentials" });

                if (!PasswordHasher.Verify(dto.Password, user.PasswordHash))
                    return Unauthorized(new { message = "Invalid credentials" });

                var token = GenerateJwtToken(user);

                return Ok(new
                {
                    token,
                    user = new
                    {
                        id = user.Id,
                        fullName = user.FullName,
                        email = user.Email,
                        phone = user.Phone,
                        profileImage = user.ProfileImage,
                        gender = user.Gender
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login for Email={Email}", dto.Email);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while logging in." });
            }
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            try
            {
                await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during logout");
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while logging out." });
            }
        }

        private string GenerateJwtToken(UserModel user)
        {
            var jwtKey = _config["Jwt:Key"];
            var jwtIssuer = _config["Jwt:Issuer"];

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim("fullName", user.FullName),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: jwtIssuer,
                audience: jwtIssuer,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }
}
