﻿using HFilesAPI.Data;
using HFilesAPI.Models;
using MySql.Data.MySqlClient;
using System.Data;

namespace HFilesAPI.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IDbConnectionFactory _factory;
        private readonly ILogger<UserRepository> _logger;

        public UserRepository(IDbConnectionFactory factory, ILogger<UserRepository> logger)
        {
            _factory = factory;
            _logger = logger;
        }

        public async Task<int> CreateUserAsync(UserModel user)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_CreateUser";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new MySqlParameter("p_full_name", user.FullName));
                cmd.Parameters.Add(new MySqlParameter("p_email", user.Email));
                cmd.Parameters.Add(new MySqlParameter("p_gender", user.Gender ?? ""));
                cmd.Parameters.Add(new MySqlParameter("p_phone", user.Phone ?? ""));
                cmd.Parameters.Add(new MySqlParameter("p_password_hash", user.PasswordHash));
                cmd.Parameters.Add(new MySqlParameter("p_created_at", user.CreatedAt));

                var outId = new MySqlParameter("p_id", MySqlDbType.Int32)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outId);

                await cmd.ExecuteNonQueryAsync();
                return Convert.ToInt32(outId.Value);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while creating user {Email}", user.Email);
                throw; // let controller decide response
            }
        }

        public async Task<UserModel?> GetByEmailAsync(string email)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_GetUserByEmail";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new MySqlParameter("p_email", email));

                using var reader = await cmd.ExecuteReaderAsync();
                if (!await reader.ReadAsync()) return null;

                return new UserModel
                {
                    Id = reader.GetInt32("id"),
                    FullName = reader.GetString("full_name"),
                    Email = reader.GetString("email"),
                    Gender = reader["gender"] as string,
                    Phone = reader.IsDBNull(reader.GetOrdinal("phone")) ? null : reader.GetString("phone"),
                    ProfileImage = reader.IsDBNull(reader.GetOrdinal("profile_image")) ? null : reader.GetString("profile_image"),
                    PasswordHash = reader.GetString("password_hash"),
                    CreatedAt = reader.GetDateTime("created_at")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while fetching user by Email={Email}", email);
                throw;
            }
        }

        public async Task<UserModel?> GetByIdAsync(int id)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_GetUserById";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new MySqlParameter("p_id", id));

                using var reader = await cmd.ExecuteReaderAsync();
                if (!await reader.ReadAsync()) return null;

                return new UserModel
                {
                    Id = reader.GetInt32("id"),
                    FullName = reader.GetString("full_name"),
                    Email = reader.GetString("email"),
                    Gender = reader["gender"] as string,
                    Phone = reader["phone"] as string,
                    PasswordHash = reader.GetString("password_hash"),
                    CreatedAt = reader.GetDateTime("created_at")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while fetching user by Id={UserId}", id);
                throw;
            }
        }

        public async Task UpdateProfileAsync(UserModel user)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_UpdateUserProfile";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new MySqlParameter("p_id", user.Id));
                cmd.Parameters.Add(new MySqlParameter("p_full_name", user.FullName));
                cmd.Parameters.Add(new MySqlParameter("p_email", user.Email));
                cmd.Parameters.Add(new MySqlParameter("p_gender", user.Gender ?? ""));
                cmd.Parameters.Add(new MySqlParameter("p_phone", user.Phone ?? ""));

                await cmd.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while updating profile for UserId={UserId}", user.Id);
                throw;
            }
        }

        public async Task UpdateProfileImageAsync(int id, string image)
        {
            try
            {
                using var conn = _factory.CreateConnection();
                await conn.OpenAsync();

                using var cmd = conn.CreateCommand();
                cmd.CommandText = "sp_UpdateUserProfileImage";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new MySqlParameter("p_id", id));
                cmd.Parameters.Add(new MySqlParameter("p_profile_picture", image));

                await cmd.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while updating profile for UserId={UserId}", id);
                throw;
            }
        }
    }
}
