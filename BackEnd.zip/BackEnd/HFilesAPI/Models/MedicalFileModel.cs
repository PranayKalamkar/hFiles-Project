﻿namespace HFilesAPI.Models
{
    public class MedicalFileModel
    {
        public int Id { get; set; } = 0;
        public int UserId { get; set; } = 0;
        public string FileType { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public string StoredFileName { get; set; } = string.Empty;
        public string MimeType { get; set; } = string.Empty;
        public long SizeBytes { get; set; } = 0;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
