﻿using Microsoft.AspNetCore.Mvc;

namespace HFilesAPI.Models
{
    public class FileUploadModel
    {
        [FromForm(Name = "files")]
        public List<IFormFile> Files { get; set; }

        [FromForm(Name = "fileType")]
        public string FileType { get; set; } = string.Empty;

        [FromForm(Name = "fileName")]
        public string FileName { get; set; } = string.Empty;
    }
}
