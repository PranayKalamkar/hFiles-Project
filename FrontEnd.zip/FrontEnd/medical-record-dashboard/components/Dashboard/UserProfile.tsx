// components/Dashboard/UserProfile.tsx
'use client';

import React, { useState, useRef } from 'react';
import Input from '../UI/Input';
import Button from '../UI/Button';
import { User } from '../../types';
import { api } from '../../services/api';

interface UserProfileProps {
  user: User;
  onUpdate: (user: User) => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ user, onUpdate }) => {
  const [formData, setFormData] = useState<User>(user);
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [imageLoading, setImageLoading] = useState(false);
  const [message, setMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedTypes.includes(file.type)) {
        setMessage('Only JPG and PNG images are allowed');
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setMessage('Image must be less than 5MB');
        return;
      }
      
      setProfileImage(file);
      setMessage('');
      
      // Create preview
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const uploadProfileImage = async () => {
    if (!profileImage) return null;

    setImageLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', profileImage);
      
      const response = await api.uploadProfileImage(formData);
      return response.filePath;
    } catch (err: any) {
      setMessage(err.message || 'Failed to upload profile image');
      return null;
    } finally {
      setImageLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      let profileImagePath = formData.profileImage;
      
      // Upload new profile image if selected
      if (profileImage) {
        profileImagePath = await uploadProfileImage();
        if (!profileImagePath) {
          return; // Upload failed, error message already set
        }
      }

      // Update user data
      const updatedUser = {
        ...formData,
        profileImage: profileImagePath || formData.profileImage
      };

      await api.updateProfile(updatedUser);
      onUpdate(updatedUser);
      setMessage('Profile updated successfully');
      setProfileImage(null);
    } catch (err: any) {
      setMessage(err.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Profile Settings</h2>
      
      {message && (
        <div className={`mb-4 px-4 py-3 rounded ${
          message.includes('successfully') 
            ? 'bg-green-100 border border-green-400 text-green-700' 
            : 'bg-red-100 border border-red-400 text-red-700'
        }`}>
          {message}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex items-start space-x-6">
          <div className="flex-shrink-0">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center overflow-hidden border-2 border-blue-300">
              {previewUrl ? (
                <img 
                  src={previewUrl} 
                  alt="Profile preview" 
                  className="w-full h-full object-cover"
                />
              ) : user.profileImage ? (
                <img 
                  src={api.getImageUrl(user.profileImage)!} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />
              ) : null}
              
              {(!previewUrl && !user.profileImage) && (
                <span className="text-blue-600 font-semibold text-lg">
                  {getInitials(user.fullName)}
                </span>
              )}
              
              {imageLoading && (
                <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex-1">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageChange}
              accept="image/jpeg,image/png,image/jpg"
              className="hidden"
            />
            <div className="space-y-2">
              <Button 
                type="button" 
                variant="secondary"
                onClick={triggerFileInput}
                disabled={imageLoading}
              >
                {profileImage ? 'Change Image' : 'Upload Image'}
              </Button>
              <p className="text-sm text-gray-500">
                JPG or PNG, max 5MB
              </p>
              {profileImage && (
                <p className="text-sm text-gray-600 truncate">
                  Selected: {profileImage.name}
                </p>
              )}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Full Name"
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
          
          <Input
            label="Email"
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Gender
            </label>
            <div className="flex space-x-4">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="gender"
                  value="Male"
                  checked={formData.gender === 'Male'}
                  onChange={handleChange}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2">Male</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="gender"
                  value="Female"
                  checked={formData.gender === 'Female'}
                  onChange={handleChange}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2">Female</span>
              </label>
            </div>
          </div>
          
          <Input
            label="Phone Number"
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Enter your phone number"
          />
        </div>
        
        <Button 
          type="submit" 
          disabled={loading || imageLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 py-3"
        >
          {loading ? 'Saving Changes...' : 'Save Changes'}
          {(loading || imageLoading) && (
            <span className="ml-2">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white inline-block"></div>
            </span>
          )}
        </Button>
      </form>
    </div>
  );
};

export default UserProfile;