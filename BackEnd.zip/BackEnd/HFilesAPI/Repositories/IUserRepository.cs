﻿using HFilesAPI.Models;

namespace HFilesAPI.Repositories
{
    public interface IUserRepository
    {
        Task<int> CreateUserAsync(UserModel user);
        Task<UserModel?> GetByEmailAsync(string email);
        Task<UserModel?> GetByIdAsync(int id);
        Task UpdateProfileAsync(UserModel user);
        Task UpdateProfileImageAsync(int id, string image);
    }
}
