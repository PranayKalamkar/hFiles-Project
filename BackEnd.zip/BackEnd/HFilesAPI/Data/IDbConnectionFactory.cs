﻿using MySql.Data.MySqlClient;
using System.Data;

namespace HFilesAPI.Data
{
    public interface IDbConnectionFactory
    {
        MySqlConnection CreateConnection();
    }
}
