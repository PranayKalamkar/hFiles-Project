import { LoginData, RegisterData, User } from "../types";

// services/api.ts
const API_BASE_URL = (typeof window !== 'undefined' && (window as any).NEXT_PUBLIC_API_URL) || 'https://localhost:7217/api';

export const api = {
 async request(endpoint: string, options: RequestInit = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  const token = localStorage.getItem('token');

  const headers: HeadersInit = {
    ...options.headers,
  };

  // only add JSON content-type if not FormData
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    if (response.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/auth/login';
    }

    let errorMessage = `API error: ${response.status}`;
    try {
      const errData = await response.json();
      errorMessage = errData.message || errorMessage;
    } catch { /* ignore parse errors */ }

    throw new Error(errorMessage);
  }

  return response.json();
},

  
  // Auth endpoints
  login: (data: LoginData) => 
    api.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    
  register: (data: RegisterData) => 
    api.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    
  // User endpoints
  getProfile: () => api.request('/users/me'),
  
  updateProfile: (data: User) => 
    api.request('/users/me', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
    
  // Medical files endpoints
  uploadFile: (formData: FormData) => 
    api.request('/Files', {
      method: 'POST',
      headers: {}, // Let browser set content-type for FormData
      body: formData,
    }),
    
  getFiles: () => api.request('/files'),
  
  deleteFile: (id: number) => 
    api.request(`/files/${id}`, {
      method: 'DELETE',
    }),

    uploadProfileImage: async (formData: FormData) => {
      try {
        const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
      
      const headers: HeadersInit = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      const response = await fetch(`${API_BASE_URL}/users/profile-image`, {
        method: 'POST',
        headers,
        body: formData,
      });
      
      if (!response.ok) {
        let errorMessage = 'Failed to upload profile image';
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorMessage;
        } catch (e) {
          errorMessage = response.statusText || errorMessage;
        }
        
        if (response.status === 401 && typeof window !== 'undefined') {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          window.location.href = '/auth/login';
        }
        
        throw new Error(errorMessage);
      }
      
      return response.json();
      } catch (error) {
        if (error instanceof Error) {
          throw error;
        }
        throw new Error('Failed to upload profile image');
      }
    },


    // Helper method to get full image URL
  getImageUrl: (path: string | undefined) => {
    if (!path) return null;
    
    // If it's already a full URL, return as is
    if (path.startsWith('http')) return path;
    
    // Otherwise, construct the full URL
    const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'https://localhost:7217';
    return `${baseUrl}${path}`;
  },
  
  // Method to get profile image directly (if needed)
  getProfileImage: async (userId: number) => {
    const response = await fetch(`${API_BASE_URL}/users/profile-image/${userId}`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch profile image');
    }
    
    // For binary image data, you might want to handle it differently
    return response.blob();
  },
};