﻿using HFilesAPI.Models;
using HFilesAPI.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HFilesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FilesController : ControllerBase
    {
        private readonly IFileRepository _fileRepo;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<FilesController> _logger;

        public FilesController(IFileRepository fr, IWebHostEnvironment env, ILogger<FilesController> logger)
        {
            _fileRepo = fr;
            _env = env;
            _logger = logger;
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Upload([FromForm] FileUploadModel dto)
        {
            try
            {
                if (!User.Identity?.IsAuthenticated ?? true)
                    return Unauthorized(new { message = "You must be logged in" });

                if (dto.Files == null || dto.Files.Count == 0)
                    return BadRequest(new { message = "At least one file is required" });

                var allowed = new[] { "application/pdf", "image/png", "image/jpeg", "image/jpg", "image/gif" };
                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

                var userDir = Path.Combine(_env.ContentRootPath, "Uploads", userId.ToString());
                Directory.CreateDirectory(userDir);

                var uploadedIds = new List<int>();

                foreach (var file in dto.Files)
                {
                    if (!allowed.Contains(file.ContentType))
                        return BadRequest(new { message = $"File {file.FileName} has unsupported format" });

                    var ext = Path.GetExtension(file.FileName);
                    var storedFileName = $"{Guid.NewGuid()}{ext}";
                    var path = Path.Combine(userDir, storedFileName);

                    // file system save
                    try
                    {
                        using var stream = new FileStream(path, FileMode.Create);
                        await file.CopyToAsync(stream);
                    }
                    catch (IOException ioEx)
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError,
                            new { message = $"Failed to save file {file.FileName}", error = ioEx.Message });
                    }

                    // DB insert
                    try
                    {
                        var meta = new MedicalFileModel
                        {
                            UserId = userId,
                            FileType = dto.FileType,
                            FileName = string.IsNullOrWhiteSpace(dto.FileName) ? file.FileName : dto.FileName,
                            StoredFileName = storedFileName,
                            MimeType = file.ContentType,
                            SizeBytes = file.Length,
                            CreatedAt = DateTime.UtcNow
                        };

                        var id = await _fileRepo.AddAsync(meta);
                        uploadedIds.Add(id);
                    }
                    catch (Exception dbEx)
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError,
                            new { message = $"Failed to save metadata for {file.FileName}", error = dbEx.Message });
                    }
                }

                return Ok(new { uploaded = uploadedIds });
            }
            catch (Exception ex)
            {
                // generic catch for unexpected errors
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "Unexpected error while uploading files", error = ex.Message });
            }
        }



        [HttpGet]
        [Authorize]
        public async Task<IActionResult> List()
        {
            try
            {
                if (!User.Identity?.IsAuthenticated ?? true)
                    return Unauthorized(new { message = "User is not authenticated" });

                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
                var items = await _fileRepo.GetByUserAsync(userId);
                return Ok(items);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching file list for UserId={UserId}",
                                 User.FindFirstValue(ClaimTypes.NameIdentifier));
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while fetching files." });
            }
        }

        [HttpGet("{id}")]
        [Authorize]
        public async Task<IActionResult> GetFile(int id)
        {
            try
            {
                if (!User.Identity?.IsAuthenticated ?? true)
                    return Unauthorized(new { message = "User is not authenticated" });

                var meta = await _fileRepo.GetByIdAsync(id);
                if (meta == null)
                    return NotFound(new { message = "File not found" });

                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
                if (meta.UserId != userId)
                    return Forbid();

                var filePath = Path.Combine(_env.ContentRootPath, "Uploads", userId.ToString(), meta.StoredFileName);
                if (!System.IO.File.Exists(filePath))
                    return NotFound(new { message = "File not found on disk" });

                var stream = System.IO.File.OpenRead(filePath);
                return File(stream, meta.MimeType);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving file Id={FileId}", id);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while retrieving the file." });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!User.Identity?.IsAuthenticated ?? true)
                    return Unauthorized(new { message = "User is not authenticated" });

                var meta = await _fileRepo.GetByIdAsync(id);
                if (meta == null)
                    return NotFound(new { message = "File not found" });

                var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
                if (meta.UserId != userId)
                    return Forbid();

                var filePath = Path.Combine(_env.ContentRootPath, "Uploads", userId.ToString(), meta.StoredFileName);
                if (System.IO.File.Exists(filePath))
                    System.IO.File.Delete(filePath);

                await _fileRepo.DeleteAsync(id);
                return Ok(new { message = "File deleted successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting file Id={FileId}", id);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { message = "An error occurred while deleting the file." });
            }
        }
    }
}
